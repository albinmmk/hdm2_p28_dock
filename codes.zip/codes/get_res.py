import mdtraj as md
import numpy as np

# Load the topology
topology = md.load('prt.pdb').topology

# Load the contact pairs indices from res.txt
cont = np.loadtxt('res4.txt', dtype=int)
cont -= 1
cont[:, 1] += 87

# Function to get residue information
def get_residue_info(index):
    residue = topology.residue(index)
    return f"{residue.name}{residue.resSeq}"

# Create and open the output file
with open('4residues.dat', 'w') as f:
    for pair in cont:
        res1 = get_residue_info(pair[0])
        res2 = get_residue_info(pair[1])
        f.write(f"{res1}-{res2}\n")
