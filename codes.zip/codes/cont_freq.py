import time
import mdtraj as md
import numpy as np
import matplotlib.pyplot as plt
from mpi4py import MPI

# Start timer
start_time = time.time()

# Initialize MPI
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

cutoff = 0.45
nframes = 10000
# Function to compute contacts for a subset of frames
def compute_contacts(frames, cont, cutoff):
    # Initialize contact frequency matrix and count list
    contact_freq = np.zeros((87, 28))
    count_list = []

    # Compute contacts for each frame
    for i in frames:
        frame = md.load_frame("last50ns.xtc", i, top="../prt.pdb")
        distances, pairs = md.compute_contacts(frame, contacts=cont, scheme='closest-heavy', ignore_nonprotein=True, periodic=True, soft_min=False, soft_min_beta=20)
#        distances, pairs = md.compute_contacts(frame, contacts=cont, scheme='ca', ignore_nonprotein=True, periodic=True, soft_min=False, soft_min_beta=20)
        count = np.sum(distances < cutoff)
#        print(i, count, flush=True)
        count_list.append((i, count))
        for j, (residue1, residue2) in enumerate(pairs):
            if distances[0, j] < cutoff:
                            contact_freq[residue1, residue2-87] += 1

    # Normalize contact frequencies by the number of frames to get probabilities
    contact_prob = contact_freq / nframes

    return contact_prob, count_list

# Define ranges of frames to process
frames_per_process = nframes // size
start_frame = rank * frames_per_process
end_frame = min((rank + 1) * frames_per_process, nframes)

# Define contact indices
range_1 = range(0, 87)
range_2 = range(87, 115)
cont = [[i, j] for i in range_1 for j in range_2]

# Compute contacts for the subset of frames assigned to this process
contact_prob_local, count_list_local = compute_contacts(range(start_frame, end_frame), cont, cutoff)

# Gather results on root process
contact_prob_all = comm.gather(contact_prob_local, root=0)
count_list_all = comm.gather(count_list_local, root=0)

# Write contact probabilities to a file, create a heat map, and write counts to count.dat on root process
if rank == 0:
    # Combine contact probabilities from all processes
    contact_prob_combined = np.sum(contact_prob_all, axis=0)

    # Write contact probabilities to a file
    np.savetxt('200ns_hvy_contact_prob.dat', contact_prob_combined, fmt='%.8f')

    # Create a heat map
    plt.figure(figsize=(10, 8))
    plt.imshow(contact_prob_combined, cmap='GnBu', origin='lower', aspect='auto')
    plt.colorbar(label='Contact Probability')
    plt.xlabel('Residue Index (p28)', fontsize=14)
    plt.ylabel('Residue Index (HDM2)', fontsize=14)
    plt.title('Contact Probability Heat Map', fontsize=14)

    plt.savefig('200ns_hvy_contact_probability_heatmap.png')

    # Combine and write counts to count.dat
    with open('200ns_hvy_count.dat', 'w') as f:
        for count_list in count_list_all:
            for frame, count in count_list:
                f.write(f"{frame} {count}\n")

    # End timer and print execution time
    end_time = time.time()
    execution_time = end_time - start_time
    print(f"Execution time: {execution_time:.2f} seconds")
