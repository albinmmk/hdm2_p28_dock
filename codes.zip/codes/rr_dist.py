from mpi4py import MPI
import mdtraj as md
import numpy as np

nframes = 20001
filename = 'distances.dat'

# MPI initialization
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

# Load contact pairs from 'res.txt'
def load_contact_pairs(file_name):
    return np.loadtxt(file_name, dtype=int)

# Define the contact pairs from the file
cont = load_contact_pairs('res.txt')
cont -= 1
cont[:, 1] += 87
#print(cont)

format_string = '%8.4f ' + ' '.join(['%8.6f'] * len(cont))

# Function to compute contacts for a single frame
def compute_frame_contacts(frame_index, cont):
    frame = md.load_frame("../nopbc.xtc", frame_index, top="prt.pdb")
    distances, pairs = md.compute_contacts(
        frame, contacts=cont, scheme='closest-heavy', ignore_nonprotein=True, periodic=True, soft_min=False, soft_min_beta=20)
    
    # Create data with frame number at the beginning
    data = np.column_stack((np.full(len(distances), frame_index*0.005), distances))
    return data

def main():
    # Master process initializes the file
    if rank == 0:
        open(filename, 'w').close()

    # Distribute frames among processes
    frames_per_process = nframes // size
    start_frame = rank * frames_per_process
    end_frame = min((rank + 1) * frames_per_process, nframes)

#    frames_per_process = nframes // size
#    extra_frames = nframes % size
#    start_frame = rank * frames_per_process + min(rank, extra_frames)
#    end_frame = start_frame + frames_per_process + (1 if rank < extra_frames else 0)

    # Each process computes its assigned frames
    for i in range(start_frame, end_frame):
        data = compute_frame_contacts(i, cont)
        with open(filename, 'a') as f:
            np.savetxt(f, data, fmt=format_string, newline='\n')

    # Synchronize processes
    comm.Barrier()

    # Only the master process will handle the sorting
    if rank == 0:
        # Read the entire file, sort, and write back
        data = np.loadtxt(filename)
        sorted_data = data[data[:, 0].argsort()]
        np.savetxt(filename, sorted_data, fmt=format_string, newline='\n')

if __name__ == "__main__":
    main()
