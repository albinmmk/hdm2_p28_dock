import numpy as np

# Load the matrix from the file
data = np.loadtxt('4.200ns_hvy_contact_prob.dat')

# Get the number of rows and columns
num_rows, num_cols = data.shape

# Open a new file to write the output
with open('heat_hvy.dat', 'w') as file:
    # Iterate over each element in the matrix
    for row in range(num_rows):
        for col in range(num_cols):
            # Get the value from the matrix
            value = data[row, col]
            # Write the row index (shifted by 24), column index, and value to the file
            file.write(f"{row + 25} {col+1} {value:.8f}\n")
