import matplotlib.pyplot as plt
import numpy as np

# Get the 'GnBu' colormap
cmap = plt.get_cmap('GnBu')
num_colors = 256  # Number of colors in the colormap

# Get RGB values
colors = cmap(np.linspace(0, 1, num_colors))

# Save to a text file
np.savetxt('gnbu_colormap.txt', colors, fmt='%.6f', delimiter=',', header='R,G,B,A', comments='')
