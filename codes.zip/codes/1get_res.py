import mdtraj as md
import numpy as np

# Load the topology from the PDB file
topology = md.load('prt.pdb').topology

# Load the contact pair indices from the file 'res.txt'
cont = np.loadtxt('00res.txt', dtype=int)

# Adjust the indices for 0-based indexing and the correct residue numbering
# Residue numbers are adjusted based on the chain's numbering offset
cont -= 1  # Convert 1-based indexing in 'res.txt' to 0-based
cont[:, 0] -= 24
cont[:, 1] += 87  # Offset for the second chain: adjust based on your input

# Function to get residue information (name and residue number)
def get_residue_info(index):
    residue = topology.residue(index)
    return f"{residue.name}{residue.resSeq}"

# Create and open the output file 'residues.dat'
with open('residues.dat', 'w') as f:
    # Iterate through each contact pair
    for pair in cont:
        # Get residue information for both residues in the pair
        res1 = get_residue_info(pair[0])
        res2 = get_residue_info(pair[1])

        # Write the residue pair information to the output file
        f.write(f"{res1}-{res2}\n")

        # Print the contact pairs for verification (optional)
        print(pair[0]+25, pair[1]-86, '  ', f"{res1}-{res2}")
