import numpy as np

# Read the data from the file
data = np.loadtxt('8.200ns_hvy_contact_prob.dat', delimiter=' ')

# Get the indices and values
indices = [(i, j) for i in range(data.shape[0]) for j in range(data.shape[1])]
values = data.flatten()

# Combine indices and values and sort by values in descending order
sorted_indices_values = sorted(zip(indices, values), key=lambda x: x[1], reverse=True)

# Write the sorted indices and values to an output file
with open('8.hvy_res.txt', 'w') as f:
    for (i, j), value in sorted_indices_values:
#        f.write(f'({i+1}, {j+1}): {value}\n')
        f.write(f'{i+25:6d}{j+1:6d}{value:10.6f}\n')
