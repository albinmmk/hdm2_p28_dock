import numpy as np

def remove_duplicates(arr):
    """Remove duplicates from an array while preserving order."""
    seen = set()
    result = []
    for item in arr:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result

# Define file path
input_file = 'res.txt'

# Read the file into a numpy array with integer type
data = np.loadtxt(input_file, dtype=int)

# Remove duplicates from each column
unique_first_column = remove_duplicates(data[:, 0])
unique_second_column = remove_duplicates(data[:, 1] + 87)

# Print the unique values to the terminal
# Print the unique values from the first column
print(" ".join(map(str, unique_first_column)))

# Print the unique values from the modified second column
print(" ".join(map(str, unique_second_column)))
